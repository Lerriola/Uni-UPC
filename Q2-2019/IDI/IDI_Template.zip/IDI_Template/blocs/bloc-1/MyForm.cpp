#include "MyForm.h"

MyForm::MyForm (QWidget* parent) : QWidget(parent)
{
  ui.setupUi(this);
}


